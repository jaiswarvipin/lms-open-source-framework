<?php 
	include_once('header.php');
	echo $body;
	include_once('footer.php');
?>