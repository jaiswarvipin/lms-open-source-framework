 	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>jquery-3.2.1.js"></script>
	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>jquery.fancybox<?php echo $strFileName?>.js"></script>
  	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>materialize.min.js"></script>
  	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>jquery.validate<?php echo $strFileName?>.js"></script>
	
  	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>default<?php echo $strFileName?>.js?v=1.0.0.0.0"></script>
  	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>validation<?php echo $strFileName?>.js?v=1.0.0.0.0"></script>
  	<script type="text/javascript" src="<?php echo SITE_URL.RESOURCE_SCRIPT_PATH?>function<?php echo $strFileName?>.js?v=1.0.0.0.0"></script>
  	<?php unset($strFileName);?>
</body>

</html>