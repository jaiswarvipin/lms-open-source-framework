<div class="col s12">
		<table class="bordered highlight  responsive-table">
	        <thead>
	          <tr>
	              <th><input type="checkbox" id="test5" /><label for="test5"></label></th>
	              <th>Lead Reg. Date</th>
	              <th>Lead Assigment Date</th>
	              <th>Name</th>
	              <th>Contact No.</th>
	              <th>Region</th>
	              <th>Branch</th>
	              <th>Lead Owner</th>
	              <th>Status</th>
	              <th>Comments</th>
	              <th>Action</th>
	          </tr>
	        </thead>

	        <tbody>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>Alvin</td>
	            <td>9773596947</td>
	            <td>Eclair</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>New</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Alan</td>
	            <td>9773596947</td>
	            <td>Jellybean</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Jonathan</td>
	            <td>9773596947</td>
	            <td>Lollipop</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>Alvin</td>
	            <td>9773596947</td>
	            <td>Eclair</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>New</td>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Alan</td>
	            <td>9773596947</td>
	            <td>Jellybean</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Jonathan</td>
	            <td>9773596947</td>
	            <td>Lollipop</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>02 Jan 2017<br />12:00:23</td>
	            <td>Alvin</td>
	            <td>9773596947</td>
	            <td>Eclair</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>New</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Alan</td>
	            <td>9773596947</td>
	            <td>Jellybean</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	          <tr>
	          	<td><input type="checkbox" id="test5" /><label for="test5"></label></td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	          	<td>02 Jan 2017<br />12:00:23</td>
	            <td>Jonathan</td>
	            <td>9773596947</td>
	            <td>Lollipop</td>
	            <td>Jaipur</td>
	            <td>Maharashrta Mumbai</td>
	            <td>Contacted</td>
	            <th>Comments Comments Comments Comments Comments Comments Comments Comments Comments Comments</th>
	            <td><a href="#!" class="waves-effect waves-circle waves-light btn-floating secondary-content"><i class="material-icons">edit</i></a></td>
	          </tr>
	        </tbody>
	      </table>
	      <ul class="pagination right">
		    <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
		    <li class="active"><a href="#!">1</a></li>
		    <li class="waves-effect"><a href="#!">2</a></li>
		    <li class="waves-effect"><a href="#!">3</a></li>
		    <li class="waves-effect"><a href="#!">4</a></li>
		    <li class="waves-effect"><a href="#!">5</a></li>
		    <li class="waves-effect"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
		  </ul>
	</div>
</div>