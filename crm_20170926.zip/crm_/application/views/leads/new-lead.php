<form name="frmAddNewleads" id="frmAddNewleads" method="post" action="leads/leadsoperation/setNewLead">
	<?php print_r($strColumnsArr, true);?>
</form>