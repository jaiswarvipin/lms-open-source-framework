<?php

$strArr = array(
                    'retailer_id'=>1,
                    'mpos_trans_id'=>2,
                    'transaction_data'=>array(
                    'retailer_id'=>1,
                    'mpos_trans_id'=>2,
                    'transaction_data'=>2,
                    'user_mobile'=>2,
                    'unique_reference_code'=>2
    ),
                    'user_mobile'=>2,
                    'unique_reference_code'=>2
    );

echo json_encode($strArr);?>